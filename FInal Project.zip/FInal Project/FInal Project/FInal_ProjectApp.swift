//
//  FInal_ProjectApp.swift
//  FInal Project
//
//  Created by Abolons on 01/04/2022.
//

import SwiftUI
@main
struct FInal_ProjectApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
